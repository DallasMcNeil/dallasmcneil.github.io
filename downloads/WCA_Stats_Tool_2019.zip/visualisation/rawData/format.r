library(plyr)

print("Loading Data...")
records <- read.delim("WCA_export_Results.tsv", header = T)
competitions <- read.delim("WCA_export_Competitions.tsv", header = T)

print("Formatting Data...")

records$roundTypeId=NULL
records$pos=NULL
records$value1=NULL
records$value2=NULL
records$value3=NULL
records$value4=NULL
records$value5=NULL
records$personName=NULL
records$personCountryId=NULL
records$formatId=NULL
records$personCountryId=NULL
records$regionalSingleRecord=NULL
records$regionalAverageRecord=NULL

print("Step 1 of 4")

colnames(competitions)[1] <- "competitionId"
records <- merge(records,competitions[,c("year","month","day","competitionId")],by="competitionId")

print("Step 2 of 4")

records <- ddply(records, .(competitionId, day, year, month, eventId, personId), summarize, average = mean(average[average>0]),best = min(best[best>0]))

print("Step 3 of 4")

records2 <- ddply(records, .(year, eventId, personId), summarize, average = min(average[average>0]),best = min(best[best>0]))

print("Step 4 of 4")

records3 <- ddply(records2, .(eventId, personId), summarize, average = min(average[average>0]),best = min(best[best>0]))

print("Complete")

print("Exporting Data")
write.csv(records, file = "../formattedData/Records.csv")
write.csv(records2, file = "../formattedData/RecordsBestYear.csv")
write.csv(records3, file = "../formattedData/RecordsBestAll.csv")
