Data from July 19 2019.

To open, execute the 'run' program and navigate to 'localhost:8000' in a web browser.

If you choose to update the data, please place the individual TSV files from the WCA database files (https://www.worldcubeassociation.org/results/misc/export.html TSV format) in the 'rawData' folder and run the 'dataFormat' executable. You will need R programming language installed to do so. This action will take some time.

Please contact me at dallas@dallasmcneil.com if you have any questions.