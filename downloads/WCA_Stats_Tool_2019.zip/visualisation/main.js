// Based on https://bl.ocks.org/mbostock/34f08d5e11952a80609169b7917d4172

$("#settingsMenu").accordion();
var records = [];

var year = new Date().getFullYear()
for (var k=2007;k<=year;k++) {
    $("#s211").append(new Option(k, k));
    $("#s212").append(new Option(k, k));
}

function hideSVG() {
    $("#statusText")[0].style.display = "block";
    if (records.length > 0) {
         $("#statusText")[0].innerHTML = "Generating..."
         $("#animationYear")[0].innerHTML = ""
    } 
    $("#visualisation")[0].style.webkitFilter = "blur(20px) brightness(0.5)"
}

function showSVG() {
    $("#statusText")[0].style.display = "none";
    $("#visualisation")[0].style.webkitFilter = "blur(0px) brightness(1)"
}

hideSVG()

var updateAxis = true;
var svg = d3.select("#visualisation"),
    margin = {top: 50, right:50, bottom: 220, left:80},
    margin2 = {top: window.innerHeight-130, right: 50, bottom: 50, left: 80},
    width = +window.innerWidth - margin.left - margin.right-300,
    height = +(window.innerHeight - margin.top - margin.bottom),
    height2 = 80;
    
var parseDate = d3.timeParse("%-d %-m %Y");

var x = d3.scaleTime().range([0, width]),
    x2 = d3.scaleTime().range([0, width]),
    y = d3.scaleLinear().range([height, 0]),
    y2 = d3.scaleLinear().range([height2, 0]);

var xAxis = d3.axisBottom(x),
    xAxis2 = d3.axisBottom(x2),
    yAxis = d3.axisLeft(y);

var brush;
var zoom;
var area;
var area2;

var xAxisTitle;
var yAxisTitle;

setTimeout(function() {
    d3.csv("../formattedData/RecordsBestYear.csv",type, function(error,data) {
        if (error) throw error;
        recordsYear = data
    });
},1)

setTimeout(function() {
    d3.csv("../formattedData/RecordsBestAll.csv",type, function(error,data) {
        if (error) throw error;
        recordsAll = data
    });
},1)

setTimeout(function() {
    d3.csv("../formattedData/Records.csv",type, function(error,data) {
        if (error) throw error;
        records = data
        generateVisualisation(0);
    });
},1)

function generateVisualisation(type) {
    hideSVG()
    setTimeout(function() {
        if (type==0) {
            areaColour = "rgba(255,40,70,1)"
            if ($("#comparison1")[0].checked) {
                plotPersonTimesComparison($("#s121")[0].value,$("#s122")[0].value,$("#s111")[0].value,$("#s112")[0].value,$("#s131")[0].value == "best",$("#s132")[0].value == "best")
            } else {
                plotPersonTimes($("#s121")[0].value,$("#s111")[0].value,$("#s131")[0].value == "best");
            }
        } else if (type==1) {
            areaColour = "rgba(255,40,70,1)"
            if ($("#comparison2")[0].checked) {
                plotCommunityTimesComparison($("#s211")[0].value,$("#s212")[0].value,$("#s221")[0].value,$("#s222")[0].value,$("#s231")[0].value == "best",$("#s232")[0].value == "best",parseFloat($("#s24")[0].value),$("#duplicates2")[0].checked);
            } else {
                plotCommunityTimes($("#s211")[0].value,$("#s221")[0].value,$("#s231")[0].value == "best",parseFloat($("#s24")[0].value),$("#duplicates2")[0].checked);
            }
        } else if (type==2) {
            areaColour = "rgba(255,40,70,1)"
            plotCommunityTimesAnimation($("#s31")[0].value,$("#s32")[0].value == "best",parseFloat($("#s33")[0].value),parseFloat($("#s34")[0].value),parseInt($("#s35")[0].value),$("#duplicates3")[0].checked);
        }
    },0);
}

function plotPersonTimes(event,nameId,showBest) {
    xAxisTitle = "Date"
    yAxisTitle = "Time"
    var data = records.filter(function(d) {
        return (d.personId==nameId&&d.eventId==event)
    })
    
    if (showBest) {
        data = data.map(function(d) {
            return {x:d.date,y:d.best}
        });
        data = data.filter(function(d) {
            return !isNaN(d.y)
        })
    } else {
        data = data.map(function(d) {
            return {x:d.date,y:d.average}
        });
        data = data.filter(function(d) {
            return !isNaN(d.y)
        })
    }
    data = data.sort(function(a,b) {
         return a.x-b.x;
    });
    
    if (data.length == 0) {
        $("#statusText")[0].innerHTML = "No data"
        return
    } else if (data.length < 2) {
        $("#statusText")[0].innerHTML = "Insufficient data"
        return
    }
    
    if (updateAxis) {
        x = d3.scaleTime().range([0, width]),
        x2 = d3.scaleTime().range([0, width]),
        y = d3.scaleLinear().range([height, 0]),
        y2 = d3.scaleLinear().range([height2, 0]);
    }
    
    updateGraph(data)
}


function plotPersonTimesComparison(event1,event2,nameId1,nameId2,showBest1,showBest2) {
    
    xAxisTitle = "Date"
    yAxisTitle = "Time"
    var data1 = records.filter(function(d) {
        return (d.personId==nameId1&&d.eventId==event1)
    })
    
    var data2 = records.filter(function(d) {
        return (d.personId==nameId2&&d.eventId==event2)
    })
    
    if (showBest1) {
        data1 = data1.map(function(d) {
            return {x:d.date,y:d.best}
        });
        data1 = data1.filter(function(d) {
            return !isNaN(d.y)
        })
    } else {
        data1 = data1.map(function(d) {
            return {x:d.date,y:d.average}
        });
        data1 = data1.filter(function(d) {
            return !isNaN(d.y)
        })
    }
    
    if (showBest2) {
        data2 = data2.map(function(d) {
            return {x:d.date,y:d.best}
        });
        data2 = data2.filter(function(d) {
            return !isNaN(d.y)
        })
    } else {
        data2 = data2.map(function(d) {
            return {x:d.date,y:d.average}
        });
        data2 = data2.filter(function(d) {
            return !isNaN(d.y)
        })
    }
    
    data1 = data1.sort(function(a,b) {
         return a.x-b.x;
    });
    data2 = data2.sort(function(a,b) {
         return a.x-b.x;
    });
    
    if (data1.length == 0&&data2.length == 0) {
        $("#statusText")[0].innerHTML = "No data"
        return
    } else if (data1.length < 2&&data2.length < 2) {
        $("#statusText")[0].innerHTML = "Insufficient data"
        return
    }
    
    if (updateAxis) {
        x = d3.scaleTime().range([0, width]),
        x2 = d3.scaleTime().range([0, width]),
        y = d3.scaleLinear().range([height, 0]),
        y2 = d3.scaleLinear().range([height2, 0]);
    }
    
    updateTwoGraph(data1,data2)
}

function plotCommunityTimes(year,event,showBest,resolution,duplicates) {
    var fRecords
    xAxisTitle = "Time"
    yAxisTitle = "No. of Results"
    if (year=="0") {
        if (duplicates) {
            fRecords = recordsAll.filter(function(d) {
                if (d.eventId==event) {
                    return true
                } else {
                    return false
                }
            })
        } else {
            fRecords = records.filter(function(d) {
                if (d.eventId==event) {
                    return true
                } else {
                    return false
                }
            })
        }
    } else {
        if (duplicates) {
            fRecords = recordsYear.filter(function(d) {
                if (d.eventId==event&&d.year==year) {
                    return true
                } else {
                    return false
                }
            })
        } else {
            fRecords = records.filter(function(d) {
                if (d.eventId==event&&d.year==year) {
                    return true
                } else {
                    return false
                }
            })
        }
    }
    
    fRecords = fRecords.sort(function(a,b) {
         return a.x-b.x;
    });
    
    var data = []
    for (var i=0;i<(20*60);i+=resolution) {
        data.push({x:i,y:0})
        data.push({x:i+resolution,y:0})
    }
    
    if (showBest) {
        fRecords = fRecords.filter(function(d) {
            if (d.best>0) {
                return true
            } else {
                return false
            }
        })
        for (var i=0;i<fRecords.length;i++) {
            if (fRecords[i].best < 20*60) {
                data[Math.floor(fRecords[i].best/resolution)*2].y++
                data[Math.floor(fRecords[i].best/resolution)*2+1].y++
            }
        }
    } else {
        fRecords = fRecords.filter(function(d) {
            if (d.average>0) {
                return true
            } else {
                return false
            }
        })
        for (var i=0;i<fRecords.length;i++) {
            if (fRecords[i].average < 20*60) {
                data[Math.floor(fRecords[i].average/resolution)*2].y++
                data[Math.floor(fRecords[i].average/resolution)*2+1].y++
            }
        }
    }
    
    if (updateAxis) {
        x = d3.scaleLinear().range([0, width]),
        x2 = d3.scaleLinear().range([0, width]),
        y = d3.scaleLinear().range([height, 0]),
        y2 = d3.scaleLinear().range([height2, 0]);
    }
    
    while (true) {
        if (data.length > 2) {
            if (data[1].y == 0) {
                data.shift()
                data.shift()
            } else {
                break;
            }
        } else {
            break;
        }
    }

    var i = 0;
    var total = 0;
    while (total<fRecords.length*0.95&&i<data.length-1) {
        total+=data[i].y
        i+=2
    }
    data = data.splice(0,i)

    if (data.length < 3) {
        $("#statusText")[0].innerHTML = "No data"
        return
    }
    
    updateGraph(data)
}

function plotCommunityTimesComparison(year1,year2,event1,event2,showBest1,showBest2,resolution,duplicates) {
    var fRecords1
    var fRecords2
    xAxisTitle = "Time"
    yAxisTitle = "No. of Results"
    if (year1=="0") {
        if (duplicates) {
            fRecords1 = recordsAll.filter(function(d) {
                if (d.eventId==event1) {
                    return true
                } else {
                    return false
                }
            })
        } else {
            fRecords1 = records.filter(function(d) {
                if (d.eventId==event1) {
                    return true
                } else {
                    return false
                }
            })
        }
    } else {
        if (duplicates) {
            fRecords1 = recordsYear.filter(function(d) {
                if (d.eventId==event1&&d.year==year1) {
                    return true
                } else {
                    return false
                }
            })
        } else {
            fRecords1 = records.filter(function(d) {
                if (d.eventId==event1&&d.year==year1) {
                    return true
                } else {
                    return false
                }
            })
        }
    }
    
    if (year2=="0") {
        if (duplicates) {
            fRecords2 = recordsAll.filter(function(d) {
                if (d.eventId==event2) {
                    return true
                } else {
                    return false
                }
            })
        } else {
            fRecords2 = records.filter(function(d) {
                if (d.eventId==event2) {
                    return true
                } else {
                    return false
                }
            })
        }
    } else {
        if (duplicates) {
            fRecords2 = recordsYear.filter(function(d) {
                if (d.eventId==event2&&d.year==year2) {
                    return true
                } else {
                    return false
                }
            })
        } else {
            fRecords2 = records.filter(function(d) {
                if (d.eventId==event2&&d.year==year2) {
                    return true
                } else {
                    return false
                }
            })
        }
    }
    
    fRecords1 = fRecords1.sort(function(a,b) {
         return a.x-b.x;
    });
    fRecords2 = fRecords2.sort(function(a,b) {
         return a.x-b.x;
    });
    
    var data1 = []
    var data2 = []
    for (var i=0;i<(20*60);i+=resolution) {
        data1.push({x:i,y:0})
        data1.push({x:i+resolution,y:0})
        data2.push({x:i,y:0})
        data2.push({x:i+resolution,y:0})
    }
    
    if (showBest1) {
        fRecords1 = fRecords1.filter(function(d) {
            if (d.best>0) {
                return true
            } else {
                return false
            }
        })
        for (var i=0;i<fRecords1.length;i++) {
            if (fRecords1[i].best < 20*60) {
                data1[Math.floor(fRecords1[i].best/resolution)*2].y++
                data1[Math.floor(fRecords1[i].best/resolution)*2+1].y++
            }
        }
    } else {
        fRecords1 = fRecords1.filter(function(d) {
            if (d.average>0) {
                return true
            } else {
                return false
            }
        })
        for (var i=0;i<fRecords1.length;i++) {
            if (fRecords1[i].average < 20*60) {
                data1[Math.floor(fRecords1[i].average/resolution)*2].y++
                data1[Math.floor(fRecords1[i].average/resolution)*2+1].y++
            }
        }
    }
   
    if (showBest2) {
        fRecords2 = fRecords2.filter(function(d) {
            if (d.best>0) {
                return true
            } else {
                return false
            }
        })
        for (var i=0;i<fRecords2.length;i++) {
            if (fRecords2[i].best < 20*60) {
                data2[Math.floor(fRecords2[i].best/resolution)*2].y++
                data2[Math.floor(fRecords2[i].best/resolution)*2+1].y++
            }
        }
    } else {
        fRecords2 = fRecords2.filter(function(d) {
            if (d.average>0) {
                return true
            } else {
                return false
            }
        })
        for (var i=0;i<fRecords2.length;i++) {
            if (fRecords2[i].average < 20*60) {
                data2[Math.floor(fRecords2[i].average/resolution)*2].y++
                data2[Math.floor(fRecords2[i].average/resolution)*2+1].y++
            }
        }
    }
    
    if (updateAxis) {
        x = d3.scaleLinear().range([0, width]),
        x2 = d3.scaleLinear().range([0, width]),
        y = d3.scaleLinear().range([height, 0]),
        y2 = d3.scaleLinear().range([height2, 0]);
    }

    var i = 0;
    var total1 = 0;
    var total2 = 0;
    while ((total1<fRecords1.length*0.95&&i<data1.length-1)||(total2<fRecords2.length*0.95&&i<data2.length-1)) {
        total1+=data1[i].y
        total2+=data2[i].y
        i+=2
    }
    data1 = data1.splice(0,i)
    data2 = data2.splice(0,i)
    
    while (true) {
        if (data1.length > 2) {
            if (data1[1].y == 0) {
                data1.shift()
                data1.shift()
            } else {
                break;
            }
        } else {
            break;
        }
    }
    
    while (true) {
        if (data2.length > 2) {
            if (data2[1].y == 0) {
                data2.shift()
                data2.shift()
            } else {
                break;
            }
        } else {
            break;
        }
    }


    if (data1.length < 3&&data2.length < 3) {
        $("#statusText")[0].innerHTML = "No data"
        return
    }
    
    updateTwoGraph(data1,data2)
}

function plotCommunityTimesAnimation(event,showBest,resolution,speed,repeat,duplicates) {
    var fData = []
    xAxisTitle = "Time"
    yAxisTitle = "No. of Results"
    var fRecords
    if (duplicates) {
        fRecords = recordsYear.filter(function(d) {
            if (d.eventId==event) {
                return true
            } else {
                return false
            }
        })
    } else {
        fRecords = records.filter(function(d) {
            if (d.eventId==event) {
                return true
            } else {
                return false
            }
        })
    }
    
    fRecords = fRecords.sort(function(a,b) {
         return a.x-b.x;
    });
    
    var data = []
    for (var i=0;i<(20*60);i+=resolution) {
        data.push({x:i,y:0})
        data.push({x:i+resolution,y:0})
    }
    
    if (showBest) {
        fRecords = fRecords.filter(function(d) {
            if (d.best>0) {
                return true
            } else {
                return false
            }
        })
        for (var i=0;i<fRecords.length;i++) {
            if (fRecords[i].best < 60*20) {
                data[Math.floor(fRecords[i].best/resolution)*2].y++
                data[Math.floor(fRecords[i].best/resolution)*2+1].y++
            }
        }
    } else {
        fRecords = fRecords.filter(function(d) {
            if (d.average>0) {
                return true
            } else {
                return false
            }
        })
        for (var i=0;i<fRecords.length;i++) {
            if (fRecords[i].average < 60*20) {
                data[Math.floor(fRecords[i].average/resolution)*2].y++
                data[Math.floor(fRecords[i].average/resolution)*2+1].y++
            }
        }
    }
    
    while (true) {
        if (data[1].y == 0) {
            data.shift()
            data.shift()
        } else {
            break;
        }
    }
    
    var l = 0;
    var total = 0;
    while (total<fRecords.length*0.95&&l<data.length-1) {
        total+=data[l].y
        l+=2
    }
    
    var maxY = 0
    var minX = Math.floor(data[0].x/5)*5
    var maxX = (l/2)*resolution
    
    var year = new Date().getFullYear()
    for (var k=2007;k<=year;k++) {
        var fRecords
        fRecords = records.filter(function(d) {
            if (d.eventId==event&&d.year==k+"") {
                return true
            } else {
                return false
            }
        })

        fRecords = fRecords.sort(function(a,b) {
             return a.x-b.x;
        });
        var data = []
        for (var i=0;i<(maxX);i+=resolution) {
            data.push({x:i,y:0})
            data.push({x:i+resolution,y:0})
        }
        
        if (showBest) {
            fRecords = fRecords.filter(function(d) {
                if (d.best>0) {
                    return true
                } else {
                    return false
                }
            })
            for (var i=0;i<fRecords.length;i++) {
                if (fRecords[i].best < maxX) {
                    data[Math.floor(fRecords[i].best/resolution)*2].y++
                    data[Math.floor(fRecords[i].best/resolution)*2+1].y++
                }
            }
        } else {
            fRecords = fRecords.filter(function(d) {
                if (d.average>0) {
                    return true
                } else {
                    return false
                }
            })
            for (var i=0;i<fRecords.length;i++) {
                if (fRecords[i].average < maxX) {
                    data[Math.floor(fRecords[i].average/resolution)*2].y++
                    data[Math.floor(fRecords[i].average/resolution)*2+1].y++
                }
            }
        }

        if (updateAxis) {
            x = d3.scaleLinear().range([0, width]),
            x2 = d3.scaleLinear().range([0, width]),
            y = d3.scaleLinear().range([height, 0]),
            y2 = d3.scaleLinear().range([height2, 0]);
        }
        
        while (true) {
            if (data.length > 2) {
                if (data[1].y == 0) {
                    data.shift()
                    data.shift()
                } else {
                    break;
                }
            } else {
                break
            }
        }
        for (var i=1;i<data.length;i+=2) {
            maxY = Math.max(maxY,data[i].y)
        }
        fData.push(data)
    }
    
    updateAxis = false;
    x = d3.scaleLinear().range([0, width]),
    x2 = d3.scaleLinear().range([0, width]),
    y = d3.scaleLinear().range([height, 0]),
    y2 = d3.scaleLinear().range([height2, 0]);
    x.domain([minX,maxX]);
    y.domain([0, maxY]); 
    x2.domain(x.domain());
    y2.domain(y.domain());
    xAxis = d3.axisBottom(x),
    xAxis2 = d3.axisBottom(x2),
    yAxis = d3.axisLeft(y);
    
    var k = 0
    var total = repeat
    var id = setInterval(function(){
        if (!fData[k]) {   
            total--
            if (total==0) { 
                updateAxis = true
                clearInterval(id)
            } else {
                $("#animationYear")[0].innerHTML = (2007)
                updateGraph(fData[0])
                k = 1
            }
        } else {    
            $("#animationYear")[0].innerHTML = (2007+k)   
            updateGraph(fData[k])
            k++ 
        }
    },speed*1000)
}

var areaColour = "#FF0044"

function updateGraph(data) {
    if (updateAxis) {
        x.domain([Math.floor(d3.min(data, function(d) { return d.x; })/5)*5, d3.max(data, function(d) { return d.x; })]);
        y.domain([0, d3.max(data, function(d) { return d.y; })]);
        x2.domain(x.domain());
        y2.domain(y.domain());
        xAxis = d3.axisBottom(x),
        xAxis2 = d3.axisBottom(x2),
        yAxis = d3.axisLeft(y);
    }
    
    margin = {top: 50, right:50, bottom: 220, left:80},
    margin2 = {top: window.innerHeight-130, right: 50, bottom: 50, left: 80},
    width = +window.innerWidth - margin.left - margin.right-300,
    height = +(window.innerHeight - margin.top - margin.bottom),
    height2 = 80    

    svg.attr("width", innerWidth)
       .attr("height", innerHeight)
    
    brush = d3.brushX()
        .extent([[0, 0], [width, height2]])
        .on("brush end", brushed);
            
    zoom = d3.zoom()
        .scaleExtent([1, 10])
        .translateExtent([[0, 0], [width, height]])
        .extent([[0, 0], [width, height]])
        .on("zoom", zoomed);
    
    area = d3.area()
        .curve(d3.curveLinear)
        .x(function(d) { return x(d.x); })
        .y0(height)
        .y1(function(d) { return y(d.y); })

    area2 = d3.area()
        .curve(d3.curveLinear)
        .x(function(d) { return x2(d.x); })
        .y0(height2)
        .y1(function(d) { return y2(d.y); })
    
    svg.selectAll("g")
        .remove();
    svg.select("defs")
        .remove();
    
    svg.select("text").remove()
    svg.select("text").remove()
    
    svg.append("defs")
        .append("clipPath")
        .attr("id", "clip")
        .append("rect")
        .attr("width", width)
        .attr("height", height);

    focus = svg.append("g")
        .attr("class", "focus")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        
    context = svg.append("g")
        .attr("class", "context")
        .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")")
        
    focus.append("path")
      .datum(data)
      .attr("class", "area")
      .attr("d", area)

    focus.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);

    focus.append("g")
      .attr("class", "axis axis--y")
      .call(yAxis);

    context.append("path")
      .datum(data)
      .attr("class", "area")
      .attr("d", area2);

    context.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(0," + height2 + ")")
      .call(xAxis2);

    context.append("g")
      .attr("class", "brush")
      .call(brush)
      .call(brush.move, x.range());

    svg.append("rect")
      .attr("class", "zoom")
      .attr("width", width)
      .attr("height", height)
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
      .style("pointer-events", "all")
      .call(zoom)
    
    svg.append("text")
        .attr("transform","translate(20,"+(window.innerHeight-100)/2+") rotate(270)")
        .text(yAxisTitle)
    
    svg.append("text")
        .attr("transform","translate("+((window.innerWidth-400)/2)+","+(window.innerHeight-160)+")")
        .text(xAxisTitle)
    
    for (var i=0;i<$(".area").length;i++) {
        $(".area")[i].style.fill = areaColour
    }  
    
    showSVG()
}


// FIXME: Zoom not working with multiple sources
function updateTwoGraph(data1,data2) {
    if (updateAxis) {
        yMax = Math.max(d3.max(data1, function(d) { return d.y; }),d3.max(data2, function(d) { return d.y; }))
        xMax = Math.max(d3.max(data1, function(d) { return d.x; }),d3.max(data2, function(d) { return d.x; }))
        xMin = Math.min(Math.floor(d3.min(data1, function(d) { return d.x; })/5)*5,Math.floor(d3.min(data2, function(d) { return d.x; })/5)*5)
        
        x.domain([xMin,xMax]);
        y.domain([0, yMax]);
        x2.domain(x.domain());
        y2.domain(y.domain());
        xAxis = d3.axisBottom(x),
        xAxis2 = d3.axisBottom(x2),
        yAxis = d3.axisLeft(y);
    }
    
    margin = {top: 50, right:50, bottom: 220, left:80},
    margin2 = {top: window.innerHeight-130, right: 50, bottom: 50, left: 80},
    width = +window.innerWidth - margin.left - margin.right-300,
    height = +(window.innerHeight - margin.top - margin.bottom),
    height2 = 80    

    svg.attr("width", innerWidth)
       .attr("height", innerHeight)
    
    brush = d3.brushX()
        .extent([[0, 0], [width, height2]])
        .on("brush end", brushed);
            
    zoom = d3.zoom()
        .scaleExtent([1, 10])
        .translateExtent([[0, 0], [width, height]])
        .extent([[0, 0], [width, height]])
        .on("zoom", zoomed);
    
    area = d3.area()
        .curve(d3.curveLinear)
        .x(function(d) { return x(d.x); })
        .y0(height)
        .y1(function(d) { return y(d.y); })

    area2 = d3.area()
        .curve(d3.curveLinear)
        .x(function(d) { return x2(d.x); })
        .y0(height2)
        .y1(function(d) { return y2(d.y); })
    
    svg.selectAll("g")
        .remove();
    svg.select("defs")
        .remove();
    
    svg.select("text").remove()
    svg.select("text").remove()
    
    svg.append("defs")
        .append("clipPath")
        .attr("id", "clip")
        .append("rect")
        .attr("width", width)
        .attr("height", height);

    focus = svg.append("g")
        .attr("class", "focus")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        
    context = svg.append("g")
        .attr("class", "context")
        .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")")
        
    focus.append("path")
      .datum(data1)
      .attr("fill","rgba(255,40,70,1)")
      .style("mix-blend-mode","lighten")
      .attr("d", area)
    
    focus.append("path")
      .datum(data2)
      .attr("fill","rgba(40,230,70,1)")
      .style("mix-blend-mode","lighten")
      .attr("d", area)

    focus.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);

    focus.append("g")
      .attr("class", "axis axis--y")
      .call(yAxis);

    context.append("path")
      .datum(data1)
      .attr("fill","rgba(255,40,70,1)")
      .style("mix-blend-mode","lighten")
      .attr("d", area2);
    
    context.append("path")
      .datum(data2)
      .attr("fill","rgba(40,230,70,1)")
      .style("mix-blend-mode","lighten")
      .attr("d", area2);
    
    context.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(0," + height2 + ")")
      .call(xAxis2);

    context.append("g")
      .attr("class", "brush")
      .call(brush)
      .call(brush.move, x.range());

    svg.append("rect")
      .attr("class", "zoom")
      .attr("width", width)
      .attr("height", height)
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
      .style("pointer-events", "all")
      .call(zoom)
    
    svg.append("text")
        .attr("transform","translate(20,"+(window.innerHeight-100)/2+") rotate(270)")
        .text(yAxisTitle)
    
    svg.append("text")
        .attr("transform","translate("+((window.innerWidth-400)/2)+","+(window.innerHeight-160)+")")
        .text(xAxisTitle)
    
    for (var i=0;i<$(".area").length;i++) {
        $(".area")[i].style.fill = areaColour
    }  
    
    showSVG()
}

function brushed() {
    if (d3.event.sourceEvent && d3.event.sourceEvent.type === "zoom") return; // ignore brush-by-zoom
    var s = d3.event.selection || x2.range();
    x.domain(s.map(x2.invert, x2));
    focus.select(".area").attr("d", area);
    focus.select(".axis--x").call(xAxis);
    svg.select(".zoom").call(zoom.transform, d3.zoomIdentity
      .scale(width / (s[1] - s[0]))
      .translate(-s[0], 0));
}

function zoomed() {
    if (d3.event.sourceEvent && d3.event.sourceEvent.type === "brush") return; // ignore zoom-by-brush
    var t = d3.event.transform;
    x.domain(t.rescaleX(x2).domain());
    focus.select(".area").attr("d", area);
    focus.select(".axis--x").call(xAxis);
    context.select(".brush").call(brush.move, x.range().map(t.invertX, t));
}

function type(d) {
  d.date = parseDate(d.day+" "+d.month+" "+d.year);
  d.best = parseInt(d.best)/100;
  d.average = parseInt(d.average)/100;
  return d;
}

function updateSettingsTable(tableNum) {
    var table = $("#settingsTable"+(tableNum+1)+"")[0]
    if ($("#comparison"+(tableNum+1))[0].checked) {
        table.rows[0].cells[2].children[0].style.opacity = 1;
    } else {
        table.rows[0].cells[2].children[0].style.opacity = 0.2;
    }
    for (var i=1;i<table.rows.length;i++) {
        table.rows[i].cells[2].children[0].disabled = !$("#comparison"+(tableNum+1))[0].checked;
    }
}
